#include "level.h"

Level::Level()
{
}

Level::~Level()
{
}

char Level::nextBlock()
{
}
